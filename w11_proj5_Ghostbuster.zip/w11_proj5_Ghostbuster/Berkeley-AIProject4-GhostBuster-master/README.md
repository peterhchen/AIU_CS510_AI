# Berkeley-AIProject4-GhostBuster
Files I edited:

bustersAgents.py: Agents for playing the Ghostbusters variant of Pacman.

inference.py: Code for tracking ghosts over time using their sounds.
