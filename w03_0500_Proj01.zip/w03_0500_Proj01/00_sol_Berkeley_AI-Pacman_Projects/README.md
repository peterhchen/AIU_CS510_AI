### README of the repository
### What is this repository for? ###

* This code was written in the framework of Artificial Intelligence class in University.
* Link for class website(http://cgi.di.uoa.gr/~ys02/)
* 1st version
* Information about the projects you can find here(http://ai.berkeley.edu/project_overview.html)

### How do I get set up? ###

* In each project you have to download all the files and you will have to follow the instructions from the link i have for every project
* Code written in Python 2
* If you are in Linux you don't have to do anything because Python is preinstalled,in Mac and Windows you have to download Python from here(https://www.python.org/downloads/) and install it
* To secure that Python is installed correctly run the command "python".If you get an answer like("Python is not recognised...)it means something went wrong with the installation.

### Contribution guidelines ###

* The code is tested by me several times and it is running perfectly
* In both projects i have done so far,i get the maximum of points(26 and 25 points respectively)
* To confirm that the code is running correctly execute the command "python autograder.py"(either in a Linux terminal or in Windows Powershell or in Mac terminal)

### Who do I talk to? ###

* Author:Lazaros Zervos
* Computer Science Student at National and Kapodistrian University of Athens
