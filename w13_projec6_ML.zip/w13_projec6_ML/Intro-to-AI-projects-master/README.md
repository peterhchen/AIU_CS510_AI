# Intro-to-AI-projects
Projects done in CS188 at UC Berkeley(Intro to Artificial Intelligence)
1. Search 
2. Games 
3. Reinforcement Learning 
4. Ghostbusters(HMMs and BNs)
5. Machinelearning 

Search: In this project, your Pacman agent will find paths through his maze world, both to reach a particular location and to collect food efficiently. You will build general search algorithms and apply them to Pacman scenarios.

Games: In this project, you will design agents for the classic version of Pacman, including ghosts. Along the way, you will implement both minimax and expectimax search and try your hand at evaluation function design.

Reinforcement Learning: In this project, you will implement value iteration and Q-learning. You will test your agents first on Gridworld (from class), then apply them to a simulated robot controller (Crawler) and Pacman.

Ghostbusters(HMMs and BNs): In this project, you will design Pacman agents that use sensors to locate and eat invisible ghosts. You’ll advance from locating single, stationary ghosts to hunting packs of multiple moving ghosts with ruthless efficiency.

Machine Learning: This project will be an introduction to machine learning. In this project you will build a neural network to classify digits, and more!
